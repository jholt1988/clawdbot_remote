import { FastifyInstance } from "fastify";
import { randomUUID } from "crypto";
import { withTx } from "../persistence/db";
import { canonicalBytes } from "../core/canonical";
import { sha256Hex } from "../core/hash";
import { stepHash, recordHash, CHAIN_ID } from "../core/lineage";
import { signAttestation } from "../core/attestation";

export async function registerRoutes(app: FastifyInstance) {
  app.post("/mil/evaluate", async (req, reply) => {
    const body = req.body as any;
    const { tenant_id, target_id, mode, request_id, payload } = body;

    // TODO: enforce tenant_crypto_state (ACTIVE only; else 409 TENANT_CRYPTO_BLOCKED)
    const evaluation_id = randomUUID();

    const inputs_digest = sha256Hex(canonicalBytes({ tenant_id, target_id, payload }));
    const audit_digest = sha256Hex(canonicalBytes({ parameter_override_attempts: [] }));

    // Starter: single step. Real implementation writes 6+ steps and finalizes on completion.
    const step_type = "EVAL_REQUEST_ACCEPTED_V1";
    const prev_step_hash = "GENESIS_STEP";
    const payload_digest = inputs_digest;
    const s_hash = stepHash({ tenant_id, evaluation_id, step_type, step_seq: 0, prev_step_hash, payload_digest });

    const lineage = await withTx(async (client) => {
      await client.query("INSERT INTO tenant_chain_head (tenant_id) VALUES ($1) ON CONFLICT DO NOTHING", [tenant_id]);

      await client.query(
        `INSERT INTO model_lineage_steps
         (tenant_id,evaluation_id,step_seq,step_type,payload_digest,payload_ciphertext,tenant_kms_key_id,dek_wrapped,nonce,cipher,enc_version,prev_step_hash,step_hash)
         VALUES ($1,$2,0,$3,$4,$5,$6,$7,$8,$9,1,$10,$11)
         ON CONFLICT DO NOTHING`,
        [tenant_id, evaluation_id, step_type, payload_digest, Buffer.from("ciphertext_stub"), "kms://tenant/"+tenant_id,
         Buffer.from("dek_wrapped_stub"), Buffer.from("nonce_stub"), "AES-256-GCM", prev_step_hash, s_hash]
      );

      if (mode === "async_job") {
        await client.query(
          `INSERT INTO mil_jobs (job_id,tenant_id,evaluation_id,target_id,status,mode,request_id)
           VALUES ($1,$2,$3,$4,'QUEUED',$5,$6)
           ON CONFLICT (tenant_id, request_id) DO UPDATE SET updated_at=now()`,
          [randomUUID(), tenant_id, evaluation_id, target_id, mode, request_id]
        );
        return null;
      }

      const out = { stub: true };
      const outputs_digest = sha256Hex(canonicalBytes(out));

      const head = await client.query("SELECT head_hash, sequence_no FROM tenant_chain_head WHERE tenant_id=$1 FOR UPDATE", [tenant_id]);
      const prev_hash = head.rows[0].head_hash as string;
      const sequence_no = Number(head.rows[0].sequence_no) + 1;

      const trace_root_hash = s_hash;
      const rec_hash = recordHash({ tenant_id, sequence_no, prev_hash, trace_root_hash, inputs_digest, outputs_digest, audit_digest });

      await client.query(
        `INSERT INTO model_lineage_events
         (tenant_id,evaluation_id,sequence_no,chain_id,prev_hash,record_hash,trace_root_hash,trace_steps,inputs_digest,outputs_digest,audit_digest)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [tenant_id, evaluation_id, sequence_no, CHAIN_ID, prev_hash, rec_hash, trace_root_hash, 1, inputs_digest, outputs_digest, audit_digest]
      );
      await client.query("UPDATE tenant_chain_head SET head_hash=$2, sequence_no=$3 WHERE tenant_id=$1", [tenant_id, rec_hash, sequence_no]);

      return { chain_id: CHAIN_ID, tenant_id, record_hash: rec_hash, prev_hash, trace_root_hash, trace_steps: 1 };
    });

    if (mode === "async_job") return reply.send({ status: "QUEUED", evaluation_id });
    return reply.send({ status: "COMPLETED", evaluation_id, result: { stub: true }, lineage });
  });

  app.post("/mil/lineage/verify", async (req) => {
    const { tenant_id, from_hash, to_hash } = req.body as any;
    // TODO: actually verify continuity over model_lineage_events[tenant_id] between hashes
    const result = {
      schema: "propertyos.lineage.verify_attestation.v1",
      as_of: new Date().toISOString(),
      tenant_id,
      chain_id: CHAIN_ID,
      from_hash,
      to_hash,
      chain_valid: true,
      records_verified: 0,
      break_detected: false,
      first_invalid_hash: null,
      server_nonce: randomUUID(),
    };
    const signature = signAttestation(result);
    return { result, signature };
  });
}
