import { createCipheriv, createDecipheriv, createHash, hkdfSync, randomBytes } from "crypto";
import { canonicalBytes } from "./canonical";

/**
 * Envelope encryption model:
 * - Generate random DEK (data encryption key) per payload (32 bytes)
 * - Encrypt payload bytes using AES-256-GCM with random nonce (12 bytes)
 * - Wrap DEK using tenant KEK derived from master key via HKDF (tenant-scoped) using AES-256-GCM
 *
 * Storage:
 * - payload_ciphertext: ciphertext || tag (16 bytes appended)
 * - nonce: payload nonce (12 bytes)
 * - dek_wrapped: wrap_nonce (12 bytes) || wrapped_dek_ciphertext || wrap_tag (16 bytes)
 *
 * NOTE: In production, KEK would be a KMS key; wrapping would be done by KMS (or envelope-wrapped via KMS).
 */

export type EnvelopeCipher = "AES-256-GCM";

export type EnvelopeEncrypted = {
  payload_digest: string;
  payload_ciphertext: Buffer;
  nonce: Buffer; // payload nonce
  dek_wrapped: Buffer; // wrap_nonce || wrapped_dek_ct || wrap_tag
  tenant_kms_key_id: string;
  cipher: EnvelopeCipher;
  enc_version: number;
};

function sha256Hex(buf: Buffer): string {
  return createHash("sha256").update(buf).digest("hex");
}

function getMasterKey(): Buffer {
  const b64 = process.env.MIL_MASTER_KEK_BASE64;
  if (!b64) {
    throw new Error("Missing MIL_MASTER_KEK_BASE64 (base64 32+ bytes).");
  }
  const key = Buffer.from(b64, "base64");
  if (key.length < 32) throw new Error("MIL_MASTER_KEK_BASE64 must decode to at least 32 bytes.");
  return key.subarray(0, 32);
}

export function deriveTenantKek(tenant_id: string, kms_key_id: string): Buffer {
  // Tenant-scoped KEK derived from master key + tenant_id + kms_key_id (acts as version/info)
  const master = getMasterKey();
  const salt = Buffer.from(tenant_id, "utf8");
  const info = Buffer.from(`MIL-KEK-v1:${kms_key_id}`, "utf8");
  const okm = hkdfSync("sha256", master, salt, info, 32);
  return Buffer.from(okm);
}

function aesGcmEncrypt(key: Buffer, nonce: Buffer, plaintext: Buffer): { ct: Buffer; tag: Buffer } {
  const c = createCipheriv("aes-256-gcm", key, nonce);
  const ct = Buffer.concat([c.update(plaintext), c.final()]);
  const tag = c.getAuthTag();
  return { ct, tag };
}

function aesGcmDecrypt(key: Buffer, nonce: Buffer, ciphertext: Buffer, tag: Buffer): Buffer {
  const d = createDecipheriv("aes-256-gcm", key, nonce);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(ciphertext), d.final()]);
}

export function envelopeEncrypt(params: {
  tenant_id: string;
  kms_key_id: string;
  payload: unknown;
}): EnvelopeEncrypted {
  const { tenant_id, kms_key_id, payload } = params;

  const plaintext = canonicalBytes(payload);
  const payload_digest = sha256Hex(plaintext);

  const dek = randomBytes(32);
  const payload_nonce = randomBytes(12);

  const { ct: payload_ct, tag: payload_tag } = aesGcmEncrypt(dek, payload_nonce, plaintext);
  const payload_ciphertext = Buffer.concat([payload_ct, payload_tag]);

  const kek = deriveTenantKek(tenant_id, kms_key_id);
  const wrap_nonce = randomBytes(12);
  const { ct: wrapped_dek_ct, tag: wrapped_dek_tag } = aesGcmEncrypt(kek, wrap_nonce, dek);
  const dek_wrapped = Buffer.concat([wrap_nonce, wrapped_dek_ct, wrapped_dek_tag]);

  return {
    payload_digest,
    payload_ciphertext,
    nonce: payload_nonce,
    dek_wrapped,
    tenant_kms_key_id: kms_key_id,
    cipher: "AES-256-GCM",
    enc_version: 2,
  };
}

export function envelopeDecrypt(params: {
  tenant_id: string;
  kms_key_id: string;
  payload_ciphertext: Buffer; // ct||tag
  nonce: Buffer; // payload nonce
  dek_wrapped: Buffer; // wrap_nonce||ct||tag
}): unknown {
  const { tenant_id, kms_key_id } = params;
  const kek = deriveTenantKek(tenant_id, kms_key_id);

  const wrap_nonce = params.dek_wrapped.subarray(0, 12);
  const wrap_ct_plus_tag = params.dek_wrapped.subarray(12);
  const wrap_ct = wrap_ct_plus_tag.subarray(0, wrap_ct_plus_tag.length - 16);
  const wrap_tag = wrap_ct_plus_tag.subarray(wrap_ct_plus_tag.length - 16);

  const dek = aesGcmDecrypt(kek, wrap_nonce, wrap_ct, wrap_tag);

  const ct_plus_tag = params.payload_ciphertext;
  const ct = ct_plus_tag.subarray(0, ct_plus_tag.length - 16);
  const tag = ct_plus_tag.subarray(ct_plus_tag.length - 16);

  const plaintext = aesGcmDecrypt(dek, params.nonce, ct, tag);
  return JSON.parse(plaintext.toString("utf8"));
}
