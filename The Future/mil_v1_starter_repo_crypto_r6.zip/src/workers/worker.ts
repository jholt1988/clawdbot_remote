import { randomUUID } from "crypto";
import { withTx } from "../persistence/db";
import { envelopeEncrypt } from "../core/crypto";
import { getTenantCrypto, assertTenantCryptoAllowsPayload } from "../persistence/crypto_state";
import { stepHash } from "../core/lineage";
import { finalizeEvaluation } from "../core/finalize";

const POLL_MS = Number(process.env.MIL_WORKER_POLL_MS || 1000);
const LEASE_SECONDS = Number(process.env.MIL_JOB_LEASE_SECONDS || 60);

type ClaimedJob = {
  job_id: string;
  tenant_id: string;
  evaluation_id: string | null;
  target_id: string | null;
  request_id: string;
  claim_token: string;
  job_type: "EVALUATE_TARGET" | "TENANT_REKEY" | "VERIFY_RANGE";
};

async function claimOneJob(): Promise<ClaimedJob | null> {
  return withTx(async (client) => {
    const q = await client.query(
      `SELECT job_id, tenant_id, evaluation_id, target_id, request_id, job_type
       FROM mil_jobs
       WHERE status='QUEUED'
         AND (next_attempt_at IS NULL OR next_attempt_at <= now())
         AND (locked_until IS NULL OR locked_until < now())
       ORDER BY created_at ASC
       FOR UPDATE SKIP LOCKED
       LIMIT 1`
    );
    if (q.rowCount === 0) return null;

    const row = q.rows[0];
    const claim_token = randomUUID();

    await client.query(
      `UPDATE mil_jobs
       SET status='RUNNING',
           claimed_at=now(),
           claim_token=$2,
           locked_until=now() + ($3 || ' seconds')::interval,
           updated_at=now()
       WHERE job_id=$1`,
      [row.job_id, claim_token, LEASE_SECONDS]
    );

    return {
      job_id: row.job_id,
      tenant_id: row.tenant_id,
      evaluation_id: row.evaluation_id,
      target_id: row.target_id,
      request_id: row.request_id,
      claim_token,
      job_type: row.job_type,
    };
  });
}

// -----------------------------
// Job Handlers
// -----------------------------

async function handleEvaluateTarget(job: ClaimedJob) {
  if (!job.evaluation_id) throw new Error("Missing evaluation_id for EVALUATE_TARGET");

  // Replace with real target adapter later
  const modelResult = { ok: true, version: "stub" };

  await withTx(async (client) => {
    // Enforce tenant crypto governance before encrypting/storing payload
    const crypto = await getTenantCrypto(client, job.tenant_id);
    assertTenantCryptoAllowsPayload(crypto.state);

    await client.query(
      "INSERT INTO tenant_chain_head (tenant_id) VALUES ($1) ON CONFLICT (tenant_id) DO NOTHING",
      [job.tenant_id]
    );

    const payload = {
      evaluation_id: job.evaluation_id,
      tenant_id: job.tenant_id,
      target_id: job.target_id,
      data: modelResult,
    };

    const enc = envelopeEncrypt({
      tenant_id: job.tenant_id,
      kms_key_id: crypto.kms_key_id,
      payload,
    });

    const s_hash = stepHash({
      tenant_id: job.tenant_id,
      evaluation_id: job.evaluation_id,
      step_type: "EVALUATE_TARGET_V1",
      step_seq: 0,
      prev_step_hash: "GENESIS_STEP",
      payload_digest: enc.payload_digest,
    });

    await client.query(
      `INSERT INTO model_lineage_steps
       (tenant_id,evaluation_id,step_seq,step_type,payload_digest,payload_ciphertext,tenant_kms_key_id,dek_wrapped,nonce,cipher,enc_version,prev_step_hash,step_hash)
       VALUES ($1,$2,0,'EVALUATE_TARGET_V1',$3,$4,$5,$6,$7,$8,$9,'GENESIS_STEP',$10)
       ON CONFLICT DO NOTHING`,
      [
        job.tenant_id,
        job.evaluation_id,
        enc.payload_digest,
        enc.payload_ciphertext,
        enc.tenant_kms_key_id,
        enc.dek_wrapped,
        enc.nonce,
        enc.cipher,
        enc.enc_version,
        s_hash,
      ]
    );

    await finalizeEvaluation({
      client,
      tenant_id: job.tenant_id,
      evaluation_id: job.evaluation_id,
      trace_root_hash: s_hash,
      trace_steps: 1,
      inputs_obj: { target_id: job.target_id },
      outputs_obj: modelResult,
      audit_obj: {},
    });
  });
}

async function handleTenantRekey(job: ClaimedJob) {
  await withTx(async (client) => {
    await client.query(
      `UPDATE tenant_crypto_state
       SET state='REKEY_REQUIRED', updated_at=now()
       WHERE tenant_id=$1`,
      [job.tenant_id]
    );
  });
}

async function handleVerifyRange(job: ClaimedJob) {
  // Placeholder for signed attestation job that only reads hashes/digests
  console.log("[worker] VERIFY_RANGE placeholder", job.job_id);
}

// -----------------------------
// Dispatcher
// -----------------------------

async function processJob(job: ClaimedJob) {
  switch (job.job_type) {
    case "EVALUATE_TARGET":
      return handleEvaluateTarget(job);
    case "TENANT_REKEY":
      return handleTenantRekey(job);
    case "VERIFY_RANGE":
      return handleVerifyRange(job);
    default:
      throw new Error("Unknown job type: " + job.job_type);
  }
}

// -----------------------------
// Loop
// -----------------------------

async function loop() {
  console.log("[mil-worker] envelope-crypto worker started");

  for (;;) {
    const job = await claimOneJob();
    if (!job) {
      await new Promise((r) => setTimeout(r, POLL_MS));
      continue;
    }

    try {
      await processJob(job);

      await withTx(async (client) => {
        await client.query(
          `UPDATE mil_jobs SET status='COMPLETED', updated_at=now(), locked_until=NULL WHERE job_id=$1`,
          [job.job_id]
        );
      });

      console.log("[mil-worker] completed", job.job_id, job.job_type);
    } catch (e) {
      console.error("[mil-worker] failed", job.job_id, e);
    }
  }
}

loop().catch((e) => {
  console.error(e);
  process.exit(1);
});
