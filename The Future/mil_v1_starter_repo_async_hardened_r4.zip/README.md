# MIL Service v1.0.0 (Dual-mode: sync_http + async_job)

Included:
- OpenAPI YAML: `openapi/mil_openapi_v1.yaml`
- Postgres migrations: `migrations/*.sql`
- TypeScript Fastify skeleton: `src/`
- Worker skeleton: `src/workers/worker.ts`

Env:
- DATABASE_URL
- MIL_ATTESTATION_PRIVATE_KEY_BASE64 (dev signing; replace with HSM/KMS in prod)
- MIL_ATTESTATION_KID (e.g., platform-attest-dev)
- PORT (default 8080)


## Migrations
- 001_init.sql
- 002_tenant_rekey_jobs.sql
- 003_jobs_claim_fields.sql

## Worker
- Set `MIL_WORKER_POLL_MS` (default 1000ms)
- Build then run: `npm run build` and `npm run worker`

- 004_worker_hardening.sql (retry scheduling, lease locking, DLQ)

## Worker hardening (new)
- Retries with exponential backoff + jitter (bounded)
- Lease-based locking via locked_until + reaper
- DLQ quarantine when attempts exceed limit

Env knobs:
- MIL_JOB_MAX_ATTEMPTS (default 8)
- MIL_JOB_LEASE_SECONDS (default 60)
- MIL_JOB_BACKOFF_BASE_MS (default 1000)
- MIL_JOB_BACKOFF_MAX_MS (default 300000)
- MIL_JOB_BACKOFF_JITTER_PCT (default 0.2)
- MIL_JOB_REAPER_MS (default 5000)
