import { randomUUID } from "crypto";
import { withTx } from "../persistence/db";
import { canonicalBytes } from "../core/canonical";
import { sha256Hex } from "../core/hash";
import { stepHash } from "../core/lineage";
import { finalizeEvaluation } from "../core/finalize";

const POLL_MS = Number(process.env.MIL_WORKER_POLL_MS || 1000);
const MAX_ATTEMPTS = Number(process.env.MIL_JOB_MAX_ATTEMPTS || 8);
const LEASE_SECONDS = Number(process.env.MIL_JOB_LEASE_SECONDS || 60);

const BASE_BACKOFF_MS = Number(process.env.MIL_JOB_BACKOFF_BASE_MS || 1000);
const MAX_BACKOFF_MS = Number(process.env.MIL_JOB_BACKOFF_MAX_MS || 5 * 60 * 1000);
const JITTER_PCT = Number(process.env.MIL_JOB_BACKOFF_JITTER_PCT || 0.2);
const REAPER_MS = Number(process.env.MIL_JOB_REAPER_MS || 5000);

const STEP_TYPES = [
  "LEDGER_EXTRACT_V1",
  "FEATURE_ASSEMBLY_V1",
  "PRIOR_PACK_SELECT_V1",
  "MEAN_EVAL_V1",
  "CONFIDENCE_EVAL_V1",
  "GOVERNANCE_AUDIT_V1",
] as const;

type ClaimedJob = {
  job_id: string;
  tenant_id: string;
  evaluation_id: string;
  target_id: string;
  request_id: string;
  claim_token: string;
  attempts: number; // 1-based after claim
};

function clamp(n: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, n));
}

function backoffMs(attempt: number): number {
  const exp = Math.pow(2, clamp(attempt - 1, 0, 20));
  const raw = BASE_BACKOFF_MS * exp;
  const capped = Math.min(raw, MAX_BACKOFF_MS);
  const jitter = capped * JITTER_PCT * (Math.random() * 2 - 1);
  return Math.max(0, Math.floor(capped + jitter));
}

async function reaperOnce() {
  await withTx(async (client) => {
    const q = await client.query(
      `UPDATE mil_jobs
       SET status='QUEUED',
           updated_at=now(),
           locked_until=NULL,
           claim_token=NULL,
           last_error=COALESCE(last_error,'') || '\n[reaper] lease expired; re-queued'
       WHERE status='RUNNING' AND locked_until IS NOT NULL AND locked_until < now()
       RETURNING job_id`
    );
    if (q.rowCount > 0) console.log("[mil-worker][reaper] re-queued", q.rowCount, "stale jobs");
  });
}

async function claimOneJob(): Promise<ClaimedJob | null> {
  return withTx(async (client) => {
    const q = await client.query(
      `SELECT job_id, tenant_id, evaluation_id, target_id, request_id, attempts
       FROM mil_jobs
       WHERE status='QUEUED'
         AND (next_attempt_at IS NULL OR next_attempt_at <= now())
         AND (locked_until IS NULL OR locked_until < now())
       ORDER BY created_at ASC
       FOR UPDATE SKIP LOCKED
       LIMIT 1`
    );
    if (q.rowCount === 0) return null;

    const row = q.rows[0];
    const claim_token = randomUUID();

    await client.query(
      `UPDATE mil_jobs
       SET status='RUNNING',
           claimed_at=now(),
           claim_token=$2,
           attempts=attempts+1,
           locked_until=now() + ($3 || ' seconds')::interval,
           updated_at=now()
       WHERE job_id=$1`,
      [row.job_id, claim_token, LEASE_SECONDS]
    );

    return {
      job_id: row.job_id,
      tenant_id: row.tenant_id,
      evaluation_id: row.evaluation_id,
      target_id: row.target_id,
      request_id: row.request_id,
      claim_token,
      attempts: Number(row.attempts) + 1,
    };
  });
}

async function runTargetModel(job: ClaimedJob): Promise<any> {
  // Replace with HTTP adapter
  return {
    ok: true,
    target_id: job.target_id,
    model_version: "payment-model-stub",
    outputs: { es15: 0.82, milestones: { day5: 0.62, day15: 0.84 } },
  };
}

function encryptStub(tenant_id: string, plaintext: unknown) {
  const bytes = canonicalBytes(plaintext);
  const digest = sha256Hex(bytes);
  return {
    payload_digest: digest,
    payload_ciphertext: Buffer.from(bytes), // starter only
    tenant_kms_key_id: "kms://tenant/" + tenant_id,
    dek_wrapped: Buffer.from("dek_wrapped_stub"),
    nonce: Buffer.from("nonce_stub"),
    cipher: "AES-256-GCM",
  };
}

async function processJob(job: ClaimedJob) {
  const modelResult = await runTargetModel(job);

  const stepPayloads = STEP_TYPES.map((t, i) => ({
    step_type: t,
    step_seq: i,
    payload: {
      step_type: t,
      step_seq: i,
      tenant_id: job.tenant_id,
      evaluation_id: job.evaluation_id,
      target_id: job.target_id,
      data: t === "GOVERNANCE_AUDIT_V1" ? { parameter_override_attempts: [] } : modelResult,
    },
  }));

  await withTx(async (client) => {
    const own = await client.query(
      "SELECT status, claim_token FROM mil_jobs WHERE job_id=$1 FOR UPDATE",
      [job.job_id]
    );
    if (own.rowCount !== 1) throw new Error("Job missing");
    if (own.rows[0].status !== "RUNNING" || own.rows[0].claim_token !== job.claim_token) return;

    await client.query(
      "INSERT INTO tenant_chain_head (tenant_id) VALUES ($1) ON CONFLICT (tenant_id) DO NOTHING",
      [job.tenant_id]
    );

    let prev_step_hash = "GENESIS_STEP";
    let final_step_hash = prev_step_hash;

    for (const s of stepPayloads) {
      const enc = encryptStub(job.tenant_id, s.payload);
      const s_hash = stepHash({
        tenant_id: job.tenant_id,
        evaluation_id: job.evaluation_id,
        step_type: s.step_type,
        step_seq: s.step_seq,
        prev_step_hash,
        payload_digest: enc.payload_digest,
      });

      await client.query(
        `INSERT INTO model_lineage_steps
         (tenant_id,evaluation_id,step_seq,step_type,payload_digest,payload_ciphertext,tenant_kms_key_id,dek_wrapped,nonce,cipher,enc_version,prev_step_hash,step_hash)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,1,$11,$12)
         ON CONFLICT (tenant_id, evaluation_id, step_seq) DO NOTHING`,
        [
          job.tenant_id,
          job.evaluation_id,
          s.step_seq,
          s.step_type,
          enc.payload_digest,
          enc.payload_ciphertext,
          enc.tenant_kms_key_id,
          enc.dek_wrapped,
          enc.nonce,
          enc.cipher,
          prev_step_hash,
          s_hash,
        ]
      );

      prev_step_hash = s_hash;
      final_step_hash = s_hash;
    }

    await finalizeEvaluation({
      client,
      tenant_id: job.tenant_id,
      evaluation_id: job.evaluation_id,
      trace_root_hash: final_step_hash,
      trace_steps: stepPayloads.length,
      inputs_obj: { tenant_id: job.tenant_id, target_id: job.target_id, request_id: job.request_id },
      outputs_obj: modelResult,
      audit_obj: { parameter_override_attempts: [] },
    });

    await client.query(
      `UPDATE mil_jobs
       SET status='COMPLETED', updated_at=now(),
           locked_until=NULL, next_attempt_at=NULL, last_error=NULL
       WHERE job_id=$1`,
      [job.job_id]
    );
  });
}

async function quarantineToDlq(job: ClaimedJob, errMsg: string, reason: string) {
  await withTx(async (client) => {
    const q = await client.query(
      `SELECT job_id, tenant_id, evaluation_id, target_id, mode, request_id, attempts, last_error
       FROM mil_jobs WHERE job_id=$1 LIMIT 1`,
      [job.job_id]
    );
    if (q.rowCount === 1) {
      const r = q.rows[0];
      await client.query(
        `INSERT INTO mil_jobs_dlq
         (dlq_id, job_id, tenant_id, evaluation_id, target_id, mode, request_id, attempts, last_error, dlq_reason)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [randomUUID(), r.job_id, r.tenant_id, r.evaluation_id, r.target_id, r.mode, r.request_id, r.attempts, (r.last_error||"") + "\n" + errMsg, reason]
      );
    }

    await client.query(
      `UPDATE mil_jobs
       SET status='DEAD', dlq_reason=$2, updated_at=now(),
           locked_until=NULL, next_attempt_at=NULL,
           last_error=COALESCE(last_error,'') || '\n' || $3
       WHERE job_id=$1`,
      [job.job_id, reason, errMsg]
    );
  });
}

async function scheduleRetry(job: ClaimedJob, errMsg: string) {
  const delay = backoffMs(job.attempts);
  await withTx(async (client) => {
    await client.query(
      `UPDATE mil_jobs
       SET status='QUEUED', updated_at=now(),
           locked_until=NULL,
           next_attempt_at=now() + ($2 || ' milliseconds')::interval,
           last_error=COALESCE(last_error,'') || '\n' || $3
       WHERE job_id=$1`,
      [job.job_id, delay, errMsg]
    );
  });
}

async function handleFailure(job: ClaimedJob, err: unknown) {
  const errMsg =
    err && typeof err === "object" && "stack" in (err as any)
      ? String((err as any).stack).slice(0, 2000)
      : String(err).slice(0, 2000);

  if (job.attempts >= MAX_ATTEMPTS) return quarantineToDlq(job, errMsg, "MAX_ATTEMPTS_EXCEEDED");
  return scheduleRetry(job, errMsg);
}

async function loop() {
  console.log("[mil-worker] hardened worker started");
  setInterval(() => reaperOnce().catch((e) => console.error("[mil-worker][reaper]", e)), REAPER_MS);

  for (;;) {
    const job = await claimOneJob();
    if (!job) {
      await new Promise((r) => setTimeout(r, POLL_MS));
      continue;
    }
    try {
      await processJob(job);
      console.log("[mil-worker] completed", job.job_id, job.evaluation_id);
    } catch (e) {
      await handleFailure(job, e);
      console.error("[mil-worker] handled failure", job.job_id);
    }
  }
}

loop().catch((e) => {
  console.error(e);
  process.exit(1);
});
