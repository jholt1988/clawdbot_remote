# Hard Invariants (GLOBAL_AUTONOMY_PAUSE triggers ONLY on violations)

## Invariant 1 — MIL Integrity Lock
If MIL integrity is degraded (unreachable, maintenance mode, signature/key failure):
- Workflow Engine MUST NOT execute actions.

## Invariant 2 — Global Coupling Ceilings
For every coupling edge e:
- beta_eff(e) ∈ [beta_min(e), beta_max(e)]
- alpha_eff(e) ∈ [alpha_min(e), alpha_max(e)]

## Invariant 3 — Tier Escalation Rate Cap
Per tenant per boundary:
- max % units escalating to Tier 3 ≤ CAP_TIER3_GROWTH
- max absolute Tier 3 count increase ≤ CAP_TIER3_ABS

## Invariant 4 — Spend Envelope Cap
Per tenant:
- daily/weekly/monthly auto-spend caps enforced.

## Invariant 5 — Token Security
Bundle fetch tokens must be valid, signed, short-lived, and tenant-scoped.

## Invariant 6 — Simulation determinism
Monte Carlo is deterministic given seed + scenario hash inputs.
