# Architecture

## Services
### MIL — Model Integrity Layer
- Pack storage & versioning (global + tenant overlays)
- Weekly boundary activation (atomic)
- Staged approvals (first-time activation where required)
- Signed bundle fetch tokens (short-lived)
- Hash continuity + audit ledger
- Maintenance mode pauses execution

### PM-RE — Predictive Maintenance Reference Engine
- Survival / intensity modeling
- Directional cross-risk coupling edges (β, α); θ fixed globally (for now)
- Nonlinear amplification (hybrid)
- Portfolio heatmap (property + unit drilldown) with 30/90/365 horizons
- Monte Carlo scenario simulation
- Vendor/lead-time shock (HVAC + water heaters; all actions)
- Secondary damage hazard events; severity conditioned on vintage/class with tenant calibration (2y window + mild decay)

### Workflow Engine
- Converts risk states into ActionIntents
- Fully autonomous execution within bounded caps
- Enforces spend caps, tier growth caps
- Emits canonical step payloads for audit
- Degraded mode: read-only flagged predictions if MIL unreachable

## Locked decisions
- Per-tenant percentiles; raw probability on hover
- Edge-wise coupling personalization activates edge-by-edge with edge-specific gates
- Global coupling ceilings evolve via platform-wide calibration (quarterly) and are tenant-visible by version only
- GLOBAL_AUTONOMY_PAUSE triggers ONLY on hard invariant violations
