# Simulation (Monte Carlo)

Outputs:
- full distributions (mean/median/p75/p95/p99)
- tail probabilities
- volatility metrics
- amplification frequency
- secondary damage probability + contribution

Shocks:
- Vendor/lead-time shock scoped to HVAC + water heaters and applies to all actions
- Secondary damage hazard active while unresolved; severity depends on vintage/class and can be tenant-calibrated over time

Determinism:
scenario_hash = sha256(canonical(overrides + shocks + horizon + runs + seed + pack_hashes))
