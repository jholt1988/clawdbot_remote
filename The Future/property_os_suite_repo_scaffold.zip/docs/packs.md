# Packs & Overlays

Global:
- CrossRiskPack (β, α per edge; θ, k fixed globally)
- GlobalCouplingCeilingsPack (platform envelope; calibrated quarterly)
- ShockPack (simulation-only)
- SecondaryDamagePack (global severity distributions)
- WorkflowPolicyPack (tiers, spend caps, etc.)

Tenant overlays:
- SecondaryDamageTenantPack (2y + mild decay; first activation requires human approval)
- CrossRiskTenantEdgeOverlayPack (edge-by-edge; 1y + mild decay; first activation per edge requires human approval)
