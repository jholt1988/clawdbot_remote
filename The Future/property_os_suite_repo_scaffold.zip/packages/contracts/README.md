# @propertyos/contracts

Machine-readable contracts and schemas for packs, shocks, intents, and APIs.

- OpenAPI: `openapi/`
- JSON Schemas: `src/schemas/`
- Types: `src/types.ts`
