import GlobalCouplingCeilingsPack from "./GlobalCouplingCeilingsPack.schema.json" assert { type: "json" };
import CrossRiskTenantEdgeOverlayPack from "./CrossRiskTenantEdgeOverlayPack.schema.json" assert { type: "json" };
import ShockVendorLeadTime from "./ShockVendorLeadTime.schema.json" assert { type: "json" };
import ActionIntent from "./ActionIntent.schema.json" assert { type: "json" };

export {
  GlobalCouplingCeilingsPack,
  CrossRiskTenantEdgeOverlayPack,
  ShockVendorLeadTime,
  ActionIntent,
};
