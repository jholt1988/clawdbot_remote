export type ISODateTime = string;
export type Sha256 = string;

export type RiskType = "maintenance" | "payment" | "vacancy";
export type HorizonDays = 30 | 90 | 365;
export type CouplingEdge = "M_to_R" | "R_to_M" | "M_to_V" | "R_to_V";

export interface RiskCell { percentile: number; p: number; }

export interface HeatmapRow {
  level: "property" | "unit";
  id: string;
  label: string;
  expected_loss: Record<`d${HorizonDays}`, number>;
  amplified: boolean;
  risk: Record<RiskType, Record<`d${HorizonDays}`, RiskCell>>;
  top_drivers?: string[];
}

export interface ActionIntent {
  intent_id: string;
  tenant_id: string;
  property_id?: string;
  unit_id?: string;
  risk_type: RiskType;
  horizon: HorizonDays;
  percentile: number;
  raw_probability: number;
  expected_loss_90d: number;
  amplified: boolean;
  recommended_action: string;
  priority_score: number;
  generated_at: ISODateTime;
  bundle_hash: Sha256;
  governance_state: "PENDING" | "APPROVED" | "EXECUTED" | "COMPLETED" | "RETIRED";
}

export interface SimulationRequest {
  tenant_id: string;
  bundle_hash: Sha256;
  bundle_fetch_token: string;
  horizon_days: HorizonDays;
  runs: number;
  seed: number;
  policy_overrides?: unknown;
  shocks?: unknown[];
}

export interface SimulationSummary {
  mean_loss: number;
  median_loss: number;
  p75: number;
  p95: number;
  p99: number;
  amplification_rate: number;
  global_ceiling_version: string;
  tenant_edge_overlays_active: CouplingEdge[];
  scenario_hash: Sha256;
  bundle_hash: Sha256;
}
