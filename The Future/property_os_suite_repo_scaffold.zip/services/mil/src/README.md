# MIL service

See `/docs/architecture.md`.
