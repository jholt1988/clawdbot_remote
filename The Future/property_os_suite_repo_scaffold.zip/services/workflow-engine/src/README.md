# WORKFLOW-ENGINE service

See `/docs/architecture.md`.
