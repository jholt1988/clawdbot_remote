import http from "node:http";
import { URL } from "node:url";

const PORT = Number(process.env.PORT || 4030);

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host}`);
  res.setHeader("content-type", "application/json");

  if (req.method === "GET" && url.pathname === "/health") {
    res.writeHead(200);
    res.end(JSON.stringify({ ok: true, service: "workflow-engine" }));
    return;
  }

  // TODO: implement routes in src/routes/*
  res.writeHead(404);
  res.end(JSON.stringify({ ok: false, error: "not_found" }));
});

server.listen(PORT, () => {
  console.log(`[workflow-engine] listening on :${PORT}`);
});
