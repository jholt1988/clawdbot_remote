# PMRE service

See `/docs/architecture.md`.
