# Property OS Suite (PMS + MIL + PM-RE) — Monorepo Scaffold

This repository is a **working scaffold** for the full architecture we designed:
- **PMS Core** (product layer): dashboards, portals, workflows (integrate with your existing app)
- **MIL** (Model Integrity Layer): governance, pack versioning, approvals, signed bundle fetch tokens
- **PM-RE** (Predictive Maintenance Reference Engine): survival/intensity compute, cross-risk coupling, Monte Carlo simulation
- **Workflow Engine**: Risk→Action orchestration with fully autonomous execution within bounded caps

Design principle: **probability-first, governance-first, replayable, bounded autonomy**.

## What’s included
- Monorepo structure + service skeletons (TypeScript)
- Shared **contract schemas** (JSON Schema) for packs, intents, shocks
- OpenAPI stubs for core services
- Governance & invariants docs
- Simulation spec (vendor/lead-time shock + secondary damage)

## Repo layout
- `services/mil` — Model Integrity Layer service
- `services/pmre` — Predictive Maintenance Reference Engine service
- `services/workflow-engine` — risk-to-action execution service
- `packages/contracts` — machine-readable schemas + OpenAPI + types
- `docs` — architecture, governance, invariants, simulation

## Key invariants
See `docs/invariants.md`.
