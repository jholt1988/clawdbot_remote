import { AssetGroup, ClassBucket, SecondaryEventType, VintageBucket } from "@propertyos/contracts";
import { mulberry32, quantile } from "./sim-utils";

/**
 * Global default cost quantiles (USD) for secondary events.
 * Conditioned by (event_type, vintage_bucket, class_bucket) with backoff.
 *
 * v1: minimal tables; you can expand and later replace with tenant-calibrated packs.
 */

export type Quantiles = { p50: number; p75: number; p90: number; p95: number; p99: number };

type Key = string;

function key(event: SecondaryEventType, v: VintageBucket, c: ClassBucket): Key {
  return `${event}::${v}::${c}`;
}

const GLOBAL: Record<Key, Quantiles> = {
  // Water heater leak damage is highly vintage/class sensitive (placeholder values)
  [key("WH_LEAK_WATER_DAMAGE","PRE_1970","C")]: { p50: 900, p75: 1800, p90: 3500, p95: 6000, p99: 14000 },
  [key("WH_LEAK_WATER_DAMAGE","PRE_1970","ALL" as any)]: { p50: 750, p75: 1500, p90: 3000, p95: 5200, p99: 12000 },

  [key("WH_LEAK_WATER_DAMAGE","ALL" as any,"ALL" as any)]: { p50: 600, p75: 1200, p90: 2500, p95: 4500, p99: 11000 },

  [key("HVAC_CONDENSATE_WATER_DAMAGE","ALL" as any,"ALL" as any)]: { p50: 450, p75: 900, p90: 1800, p95: 3200, p99: 8000 },
  [key("HVAC_ELECTRICAL_FAULT","ALL" as any,"ALL" as any)]: { p50: 220, p75: 420, p90: 900, p95: 1600, p99: 4200 },
  [key("HVAC_COMPRESSOR_ESCALATION","ALL" as any,"ALL" as any)]: { p50: 900, p75: 1400, p90: 2400, p95: 3800, p99: 9000 },

  [key("WH_MOLD_RISK","ALL" as any,"ALL" as any)]: { p50: 650, p75: 1200, p90: 2400, p95: 4200, p99: 11000 },
  [key("WH_PAN_OVERFLOW","ALL" as any,"ALL" as any)]: { p50: 180, p75: 350, p90: 700, p95: 1200, p99: 2800 },
};

function backoffCandidates(event: SecondaryEventType, v: VintageBucket, c: ClassBucket): Key[] {
  const ALLV = "ALL" as any;
  const ALLC = "ALL" as any;
  return [
    key(event, v, c),
    key(event, v, ALLC),
    key(event, ALLV, c),
    key(event, ALLV, ALLC),
  ];
}

export function resolveQuantiles(event: SecondaryEventType, vintage: VintageBucket, cls: ClassBucket): Quantiles {
  for (const k of backoffCandidates(event, vintage, cls)) {
    if (GLOBAL[k]) return GLOBAL[k];
  }
  // absolute fallback
  return { p50: 400, p75: 800, p90: 1600, p95: 3000, p99: 8000 };
}

export function sampleFromQuantiles(rng: () => number, q: Quantiles): number {
  // piecewise-linear inverse CDF on {0.5,0.75,0.9,0.95,0.99} with conservative tails.
  const u = rng();
  const xs = [0.0, 0.5, 0.75, 0.9, 0.95, 0.99, 1.0];
  const ys = [Math.max(1, q.p50 * 0.6), q.p50, q.p75, q.p90, q.p95, q.p99, q.p99 * 1.5];
  for (let i = 0; i < xs.length - 1; i++) {
    if (u >= xs[i] && u <= xs[i + 1]) {
      const t = (u - xs[i]) / (xs[i + 1] - xs[i]);
      return ys[i] + t * (ys[i + 1] - ys[i]);
    }
  }
  return q.p99;
}

export function secondaryEventTypesForGroup(group: AssetGroup): SecondaryEventType[] {
  if (group === "HVAC") return ["HVAC_CONDENSATE_WATER_DAMAGE","HVAC_ELECTRICAL_FAULT","HVAC_COMPRESSOR_ESCALATION"];
  return ["WH_LEAK_WATER_DAMAGE","WH_MOLD_RISK","WH_PAN_OVERFLOW"];
}
