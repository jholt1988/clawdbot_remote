import { AssetSimInput, PortfolioSimulationRequest, PortfolioSimulationResponse, ShockVendorLeadTime } from "@propertyos/contracts";
import { expSample, lognormalSample, mulberry32, quantile } from "./sim-utils";
import { resolveQuantiles, sampleFromQuantiles, secondaryEventTypesForGroup } from "./secondary-damage";

type DelayClass = "minor_repair" | "major_repair" | "replace";

function pickDelayClass(a: AssetSimInput): DelayClass {
  const kind = a.action_kind ?? "REPAIR";
  if (kind === "REPLACE") return "replace";
  const rc = a.repair_class ?? "MAJOR";
  return rc === "MINOR" ? "minor_repair" : "major_repair";
}

function findLeadTimeShock(req: PortfolioSimulationRequest): ShockVendorLeadTime | undefined {
  const shocks = req.shocks ?? [];
  return shocks.find(s => s.shock_type === "MAINT_VENDOR_LEADTIME");
}

export function simulatePortfolio(req: PortfolioSimulationRequest): PortfolioSimulationResponse {
  const horizon = Math.max(1, Math.min(365, req.horizon_days));
  const runs = Math.max(100, Math.min(20000, req.runs));
  const rng = mulberry32(req.seed >>> 0);

  const shock = findLeadTimeShock(req);
  const scopedGroups = new Set(shock?.scope.asset_groups ?? []);
  const losses: number[] = [];
  let anyPrimary = 0;
  let anySecondary = 0;

  // Baseline delay medians (days) for dispatch/parts (rough defaults)
  const baseDispatchMedian = 3; // days
  const basePartsMedian = 4;    // days
  const baseSigma = 0.6;        // lognormal sigma baseline

  for (let r = 0; r < runs; r++) {
    let loss = 0;
    let primaryThisRun = false;
    let secondaryThisRun = false;

    for (const asset of req.assets) {
      const p = Math.max(0, Math.min(0.999, asset.base_event_probability));
      // Convert to lambda/day s.t. P(event within horizon)=p
      const lambda = -Math.log(1 - p) / horizon;

      const tEvent = expSample(rng, lambda);
      if (tEvent > horizon) continue;

      primaryThisRun = true;

      // Primary event base cost (placeholder): repairs/replacements differ
      const cls = pickDelayClass(asset);
      const basePrimaryCost = cls === "replace" ? 4200 : (cls === "minor_repair" ? 350 : 950);
      loss += basePrimaryCost;

      // Compute resolution delays
      let dispatchMedian = baseDispatchMedian;
      let partsMedian = basePartsMedian;
      let sigmaDispatch = baseSigma;
      let sigmaParts = baseSigma;

      if (shock && scopedGroups.has(asset.asset_group)) {
        const dd = shock.params.dispatch[cls];
        const pp = shock.params.parts[cls];
        dispatchMedian *= dd.median_mult;
        partsMedian *= pp.median_mult;
        sigmaDispatch += dd.tail_sigma_add;
        sigmaParts += pp.tail_sigma_add;
      }

      const dDispatch = Math.max(0.1, lognormalSample(rng, dispatchMedian, sigmaDispatch));
      const dParts = Math.max(0.1, lognormalSample(rng, partsMedian, sigmaParts));
      const dWork = cls === "replace" ? 2.0 : 0.8;
      const dResolve = dDispatch + dParts + dWork;

      // Secondary damage hazard while unresolved:
      // piecewise constant hazard/day increasing with age (simple v1)
      // hvac/wh differ in baseline
      const baseSecHaz = asset.asset_group === "HVAC" ? 0.004 : 0.006; // per day
      const ageFactor = Math.min(4.0, 1.0 + dResolve / 10.0);          // increases with longer delays
      const lambdaSec = baseSecHaz * ageFactor;

      const tSec = expSample(rng, lambdaSec);
      if (tSec <= dResolve) {
        secondaryThisRun = true;

        // Pick a random secondary event type from group list
        const types = secondaryEventTypesForGroup(asset.asset_group);
        const ev = types[Math.floor(rng() * types.length)];

        const q = resolveQuantiles(ev, asset.vintage_bucket, asset.class_bucket);
        const secCost = sampleFromQuantiles(rng, q);
        loss += secCost;

        // Optional: secondary event adds downtime extension (simple)
        const extDays = Math.min(14, Math.max(0, (secCost / 2000) * 2));
        // Downtime can translate to additional cost via hotel/tenant concessions; placeholder:
        loss += extDays * 35;
      }
    }

    if (primaryThisRun) anyPrimary += 1;
    if (secondaryThisRun) anySecondary += 1;
    losses.push(loss);
  }

  losses.sort((a,b)=>a-b);

  return {
    ok: true,
    horizon_days: horizon,
    runs,
    seed: req.seed,
    summary: {
      mean_loss: losses.reduce((s,x)=>s+x,0)/losses.length,
      p50: quantile(losses, 0.50),
      p75: quantile(losses, 0.75),
      p95: quantile(losses, 0.95),
      p99: quantile(losses, 0.99),
      prob_any_primary_event: anyPrimary / runs,
      prob_any_secondary_event: anySecondary / runs,
    },
    notes: [
      "Monte Carlo v1: exponential primary event time, lognormal dispatch/parts delays, secondary hazard during unresolved window.",
      "Costs are placeholder defaults + vintage/class-conditioned secondary quantile tables (global).",
    ]
  };
}
