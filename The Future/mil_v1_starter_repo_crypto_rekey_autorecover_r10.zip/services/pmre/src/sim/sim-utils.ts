export function mulberry32(seed: number) {
  let t = seed >>> 0;
  return function () {
    t += 0x6D2B79F5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

export function expSample(rng: () => number, lambdaPerDay: number): number {
  // exponential waiting time in days
  const u = Math.max(1e-12, rng());
  return -Math.log(u) / Math.max(1e-12, lambdaPerDay);
}

// Approximate lognormal sampling given median multiplier and sigma add.
// Baseline: choose mu such that median = baseMedianDays.
export function lognormalSample(rng: () => number, baseMedianDays: number, sigma: number): number {
  // Box-Muller for standard normal
  const u1 = Math.max(1e-12, rng());
  const u2 = Math.max(1e-12, rng());
  const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  const mu = Math.log(Math.max(1e-6, baseMedianDays)); // because median = exp(mu)
  return Math.exp(mu + sigma * z);
}

export function quantile(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  if (sorted[base + 1] === undefined) return sorted[base];
  return sorted[base] + rest * (sorted[base + 1] - sorted[base]);
}
