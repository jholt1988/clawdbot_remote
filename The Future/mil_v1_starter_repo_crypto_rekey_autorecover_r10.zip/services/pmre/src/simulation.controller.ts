import { Body, Controller, Post } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { PortfolioSimulationRequest } from "@propertyos/contracts";
import { simulatePortfolio } from "./sim/monte-carlo";
import { ShockVendorLeadTimeSchema } from "@propertyos/contracts";

@ApiTags("simulation")
@Controller("simulation")
export class SimulationController {
  @Post("portfolio")
  async simulate(@Body() body: any) {
    // minimal validation
    const req: PortfolioSimulationRequest = {
      tenant_id: String(body.tenant_id ?? ""),
      horizon_days: Number(body.horizon_days ?? 90),
      runs: Number(body.runs ?? 2000),
      seed: Number(body.seed ?? 123),
      assets: Array.isArray(body.assets) ? body.assets : [],
      shocks: Array.isArray(body.shocks) ? body.shocks : undefined,
    };

    // validate shocks if present
    if (req.shocks) {
      for (const s of req.shocks) {
        const parsed = ShockVendorLeadTimeSchema.safeParse(s);
        if (!parsed.success) return { ok: false, error: parsed.error.flatten() };
      }
    }

    if (!req.tenant_id || req.assets.length === 0) return { ok: false, error: "MISSING_TENANT_OR_ASSETS" };

    return simulatePortfolio(req);
  }
}
