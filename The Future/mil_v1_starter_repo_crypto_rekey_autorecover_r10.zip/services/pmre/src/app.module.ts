import { Module } from "@nestjs/common";
import { HealthController } from "./health.controller";
import { PrismaService } from "./prisma.service";
import { SimulationController } from "./simulation.controller";

@Module({
  imports: [],
  controllers: [HealthController, SimulationController],
  providers: [PrismaService],
})
export class AppModule {}
