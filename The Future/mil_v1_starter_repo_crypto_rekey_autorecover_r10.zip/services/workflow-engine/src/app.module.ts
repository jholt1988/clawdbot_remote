import { Module } from "@nestjs/common";
import { HealthController } from "./health.controller";
import { PrismaService } from "./prisma.service";
import { IntentsController } from "./intents.controller";

@Module({
  imports: [],
  controllers: [HealthController, IntentsController],
  providers: [PrismaService],
})
export class AppModule {}
