import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { SwaggerModule, DocumentBuilder } from "@nestjs/swagger";
import { AppModule } from "./app.module";

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { cors: true });
  const config = new DocumentBuilder()
    .setTitle("workflow-engine")
    .setDescription("Property OS Suite service: workflow-engine")
    .setVersion("0.2.0")
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup("docs", app, document);

  const port = Number(process.env.PORT || 3003);
  await app.listen(port);
  console.log(`[$workflow-engine] listening on :${port}`);
}

bootstrap();
