import { Body, Controller, Post } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { PrismaService } from "./prisma.service";

/**
 * Autonomous execution stub:
 * - upserts ActionIntent (create-only v1)
 * - auto-executes if tier in {TIER_1, TIER_2} and within caps
 *
 * GLOBAL_AUTONOMY_PAUSE: only on hard invariant violations (not implemented here).
 */
@ApiTags("intents")
@Controller("intents")
export class IntentsController {
  constructor(private prisma: PrismaService) {}

  @Post("upsert")
  async upsert(@Body() body: any) {
    const maxDaily = Number(process.env.MAX_DAILY_AUTOSPEND_USD ?? 2500);
    const estCost = Number(body.estimated_cost_usd ?? 0);

    if (estCost > maxDaily) {
      await this.prisma.auditEvent.create({
        data: {
          tenantId: body.tenant_id,
          type: "AUTONOMY_SPEND_CAP_BLOCKED",
          payload: { estCost, maxDaily }
        }
      });
      return { ok: false, error: "SPEND_CAP_EXCEEDED" };
    }

    const tier = body.tier ?? "TIER_2";
    const status = (tier === "TIER_1" || tier === "TIER_2") ? "EXECUTED" : (body.status ?? "DETECTED");

    const created = await this.prisma.actionIntent.create({
      data: {
        tenantId: body.tenant_id,
        propertyId: body.property_id ?? null,
        unitId: body.unit_id ?? null,
        riskType: body.risk_type ?? "maintenance",
        horizonDays: body.horizon_days ?? 90,
        percentile: body.percentile ?? 50,
        rawProbability: body.raw_probability ?? 0.1,
        expectedLoss90d: body.expected_loss_90d ?? null,
        amplified: Boolean(body.amplified ?? false),
        recommendedAction: body.recommended_action ?? "NOOP",
        priorityScore: body.priority_score ?? 0.5,
        tier,
        status,
        bundleHash: body.bundle_hash ?? null,
        governanceJson: body.governance ?? {},
      }
    });

    return { ok: true, intent: created };
  }
}
