import { Body, Controller, Get, Param, Post, Query } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { PrismaService } from "./prisma.service";
import { EdgeOverlayCandidateRequestSchema } from "@propertyos/contracts";

/**
 * Minimal edge-by-edge activation workflow:
 * - create candidate (becomes PENDING_FIRST_APPROVAL if no ACTIVE exists for that edge)
 * - approve-first (marks APPROVED via status transition)
 * - activate (sets ACTIVE + writes AuditEvent)
 *
 * NOTE: This is baseline glue; production should enforce authZ/roles.
 */
@ApiTags("edge-overlays")
@Controller("edge-overlays")
export class EdgeOverlaysController {
  constructor(private prisma: PrismaService) {}

  @Get()
  async list(@Query("tenantId") tenantId?: string) {
    const items = await this.prisma.crossRiskTenantEdgeOverlay.findMany({
      where: { ...(tenantId ? { tenantId } : {}) },
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return { items };
  }

  @Post("candidate")
  async createCandidate(@Body() body: any) {
    const parsed = EdgeOverlayCandidateRequestSchema.safeParse(body);
    if (!parsed.success) return { ok: false, error: parsed.error.flatten() };

    const req = parsed.data;
    const tenant = await this.prisma.tenant.findUnique({ where: { id: req.tenant_id } });
    if (!tenant) return { ok: false, error: "TENANT_NOT_FOUND" };

    const hasActive = await this.prisma.crossRiskTenantEdgeOverlay.findFirst({
      where: { tenantId: req.tenant_id, edge: req.edge as any, status: "ACTIVE" },
    });

    const status = hasActive ? "CANDIDATE" : "PENDING_FIRST_APPROVAL";

    const created = await this.prisma.crossRiskTenantEdgeOverlay.create({
      data: {
        tenantId: req.tenant_id,
        edge: req.edge as any,
        parentPackHash: req.parent_cross_risk_pack_hash,
        version: req.version,
        status,
        deltaBeta: req.delta_beta,
        deltaAlpha: req.delta_alpha,
        windowDays: req.window_days,
        decayLambda: req.decay_lambda,
        neff: req.neff,
        metricsJson: req.metrics,
      },
    });

    await this.prisma.auditEvent.create({
      data: {
        tenantId: req.tenant_id,
        type: "CROSSRISK_EDGE_OVERLAY_CANDIDATE_CREATED",
        payload: { overlayId: created.id, edge: req.edge, status, neff: req.neff },
      },
    });

    return { ok: true, overlay: created };
  }

  @Post(":id/approve-first")
  async approveFirst(@Param("id") id: string, @Body() body: { note?: string }) {
    const overlay = await this.prisma.crossRiskTenantEdgeOverlay.findUnique({ where: { id } });
    if (!overlay) return { ok: false, error: "NOT_FOUND" };
    if (overlay.status !== "PENDING_FIRST_APPROVAL") return { ok: false, error: "NOT_PENDING_FIRST_APPROVAL" };

    const updated = await this.prisma.crossRiskTenantEdgeOverlay.update({
      where: { id },
      data: { status: "CANDIDATE" }, // approved to be activated at boundary
    });

    await this.prisma.auditEvent.create({
      data: {
        tenantId: overlay.tenantId,
        type: "CROSSRISK_EDGE_OVERLAY_FIRST_APPROVED",
        payload: { overlayId: id, edge: overlay.edge, note: body?.note ?? null },
      },
    });

    return { ok: true, overlay: updated };
  }

  @Post(":id/activate")
  async activate(@Param("id") id: string, @Body() body: { boundaryTag: string }) {
    const overlay = await this.prisma.crossRiskTenantEdgeOverlay.findUnique({ where: { id } });
    if (!overlay) return { ok: false, error: "NOT_FOUND" };
    if (overlay.status !== "CANDIDATE" && overlay.status !== "ACTIVE") return { ok: false, error: "NOT_ACTIVATABLE" };

    // retire previous ACTIVE for same edge
    await this.prisma.crossRiskTenantEdgeOverlay.updateMany({
      where: { tenantId: overlay.tenantId, edge: overlay.edge, status: "ACTIVE", NOT: { id } },
      data: { status: "RETIRED" },
    });

    const updated = await this.prisma.crossRiskTenantEdgeOverlay.update({
      where: { id },
      data: { status: "ACTIVE" },
    });

    await this.prisma.auditEvent.create({
      data: {
        tenantId: overlay.tenantId,
        type: "CROSSRISK_EDGE_OVERLAY_ACTIVATED",
        payload: { overlayId: id, edge: overlay.edge, boundaryTag: body.boundaryTag },
      },
    });

    return { ok: true, overlay: updated };
  }
}
