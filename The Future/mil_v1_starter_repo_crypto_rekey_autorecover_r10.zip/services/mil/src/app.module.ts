import { Module } from "@nestjs/common";
import { HealthController } from "./health.controller";
import { PrismaService } from "./prisma.service";
import { PacksController } from "./packs.controller";
import { TokensController } from "./tokens.controller";
import { EdgeOverlaysController } from "./edge-overlays.controller";

@Module({
  imports: [],
  controllers: [HealthController, PacksController, TokensController, EdgeOverlaysController],
  providers: [PrismaService],
})
export class AppModule {}
