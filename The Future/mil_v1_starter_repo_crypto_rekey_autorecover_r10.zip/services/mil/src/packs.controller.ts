import { Controller, Get, Param, Query } from "@nestjs/common";
import { ApiQuery, ApiTags } from "@nestjs/swagger";
import { PrismaService } from "./prisma.service";

@ApiTags("packs")
@Controller("packs")
export class PacksController {
  constructor(private prisma: PrismaService) {}

  @Get(":hash")
  async getByHash(@Param("hash") hash: string) {
    const pack = await this.prisma.pack.findUnique({ where: { hash } });
    return pack ? { found: true, pack } : { found: false };
  }

  @ApiQuery({ name: "kind", required: false })
  @ApiQuery({ name: "tenantId", required: false })
  @Get()
  async list(@Query("kind") kind?: string, @Query("tenantId") tenantId?: string) {
    const packs = await this.prisma.pack.findMany({
      where: { ...(kind ? { kind: kind as any } : {}), ...(tenantId ? { tenantId } : {}) },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return { packs };
  }
}
