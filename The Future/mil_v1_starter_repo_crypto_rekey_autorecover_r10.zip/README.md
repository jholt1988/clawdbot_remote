# Property OS Suite — NestJS + Prisma Baseline (r2)

This monorepo includes runnable services and **minimal working logic** for:
- **MIL**: edge-overlay candidate + first-time approval + activation (edge-by-edge)
- **PM-RE**: minimal Monte Carlo simulation engine with:
  - HVAC / Water-Heater vendor lead-time shock (all actions)
  - secondary damage hazard with vintage/class-conditioned cost distributions (global defaults; tenant pack hook points)
- **Workflow Engine**: ActionIntent upsert + autonomous execution stubs (bounded caps hooks)

## Quick start
Prereqs: Node 20+, pnpm 9+, Docker.

```bash
docker compose up -d
pnpm i

# Prisma
cp prisma/.env.example prisma/.env
pnpm db:generate
pnpm db:migrate

# Run
pnpm dev
```

Docs:
- MIL: http://localhost:3001/docs
- PM-RE: http://localhost:3002/docs
- Workflow: http://localhost:3003/docs
