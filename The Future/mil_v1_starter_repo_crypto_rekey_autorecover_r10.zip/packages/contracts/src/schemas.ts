import { z } from "zod";

export const CrossRiskEdgeSchema = z.enum(["M_to_R","R_to_M","M_to_V","R_to_V"]);

export const EdgeOverlayCandidateRequestSchema = z.object({
  tenant_id: z.string().min(1),
  edge: CrossRiskEdgeSchema,
  parent_cross_risk_pack_hash: z.string().min(1),
  version: z.string().min(1),
  delta_beta: z.number(),
  delta_alpha: z.number(),
  window_days: z.number().int().positive(),
  decay_lambda: z.number().positive(),
  neff: z.number().nonnegative(),
  metrics: z.record(z.string(), z.any())
});

export const ShockVendorLeadTimeSchema = z.object({
  shock_type: z.literal("MAINT_VENDOR_LEADTIME"),
  scope: z.object({
    asset_groups: z.array(z.enum(["HVAC","WATER_HEATER","MAJOR_APPLIANCE","ELECTRICAL_PANEL"])).min(1)
  }),
  apply_to: z.literal("ALL_ACTIONS"),
  params: z.object({
    vendor_capacity_multiplier: z.number().min(0.3).max(1.0),
    dispatch: z.object({
      minor_repair: z.object({ median_mult: z.number().min(1).max(3), tail_sigma_add: z.number().min(0).max(0.8) }),
      major_repair: z.object({ median_mult: z.number().min(1).max(3), tail_sigma_add: z.number().min(0).max(0.8) }),
      replace: z.object({ median_mult: z.number().min(1).max(3), tail_sigma_add: z.number().min(0).max(0.8) })
    }),
    parts: z.object({
      minor_repair: z.object({ median_mult: z.number().min(1).max(4), tail_sigma_add: z.number().min(0).max(1.0) }),
      major_repair: z.object({ median_mult: z.number().min(1).max(4), tail_sigma_add: z.number().min(0).max(1.0) }),
      replace: z.object({ median_mult: z.number().min(1).max(4), tail_sigma_add: z.number().min(0).max(1.0) })
    })
  })
});
