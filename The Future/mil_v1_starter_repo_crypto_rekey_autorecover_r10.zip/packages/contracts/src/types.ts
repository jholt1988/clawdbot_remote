export type CrossRiskEdge = "M_to_R" | "R_to_M" | "M_to_V" | "R_to_V";
export type PackStatus = "CANDIDATE" | "PENDING_FIRST_APPROVAL" | "ACTIVE" | "RETIRED" | "ROLLED_BACK";

export type AssetGroup = "HVAC" | "WATER_HEATER" | "MAJOR_APPLIANCE" | "ELECTRICAL_PANEL";
export type MaintActionKind = "REPAIR" | "REPLACE";
export type RepairClass = "MINOR" | "MAJOR" | "UNKNOWN";

export interface EdgeOverlayCandidateRequest {
  tenant_id: string;
  edge: CrossRiskEdge;
  parent_cross_risk_pack_hash: string;
  version: string;
  delta_beta: number;
  delta_alpha: number;
  window_days: number;   // 365
  decay_lambda: number;  // ln2/365
  neff: number;
  metrics: Record<string, unknown>;
}

export interface ShockVendorLeadTime {
  shock_type: "MAINT_VENDOR_LEADTIME";
  scope: { asset_groups: AssetGroup[] };
  apply_to: "ALL_ACTIONS";
  params: {
    vendor_capacity_multiplier: number;
    dispatch: Record<"minor_repair" | "major_repair" | "replace", { median_mult: number; tail_sigma_add: number }>;
    parts: Record<"minor_repair" | "major_repair" | "replace", { median_mult: number; tail_sigma_add: number }>;
  };
}

export type VintageBucket = "PRE_1970" | "Y1970_1989" | "Y1990_2009" | "Y2010_PLUS" | "UNKNOWN";
export type ClassBucket = "A" | "B" | "C" | "UNKNOWN";

export type SecondaryEventType =
  | "HVAC_CONDENSATE_WATER_DAMAGE"
  | "HVAC_ELECTRICAL_FAULT"
  | "HVAC_COMPRESSOR_ESCALATION"
  | "WH_LEAK_WATER_DAMAGE"
  | "WH_MOLD_RISK"
  | "WH_PAN_OVERFLOW";

export interface AssetSimInput {
  asset_id: string;
  asset_group: AssetGroup;
  vintage_bucket: VintageBucket;
  class_bucket: ClassBucket;

  // base probability of a primary maintenance event within horizon (approx)
  base_event_probability: number; // 0..1

  // used to choose delay class; for v1 defaults to MAJOR
  action_kind?: MaintActionKind;
  repair_class?: RepairClass;
}

export interface PortfolioSimulationRequest {
  tenant_id: string;
  horizon_days: number;
  runs: number;
  seed: number;
  assets: AssetSimInput[];
  shocks?: ShockVendorLeadTime[];
}

export interface PortfolioSimulationResponse {
  ok: boolean;
  horizon_days: number;
  runs: number;
  seed: number;
  summary: {
    mean_loss: number;
    p50: number;
    p75: number;
    p95: number;
    p99: number;
    prob_any_primary_event: number;
    prob_any_secondary_event: number;
  };
  notes?: string[];
}
