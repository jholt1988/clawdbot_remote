# Locked decisions (summary)

- Heatmap: property + unit drilldown in same view; show 30/90/365; raw probability on hover; per-tenant probabilities only.
- Vendor/lead-time shock: scoped to HVAC + WATER_HEATER first; applies to ALL actions (repairs + replacements).
- Secondary damage: explicit hazard during unresolved interval; costs as distributions conditioned on vintage/class; tenant-calibrated over time (2-year rolling window + mild decay) with first-time human approval; retroactively recompute live baselines without mutating history.
- Cross-risk coupling: tenant overlays learned separately per direction; edge-by-edge activation; influence real-time tiers + ActionIntents once active; bounded by global coupling ceilings.
- Global coupling ceilings: quarterly platform-wide calibration; ceiling version is tenant-visible; personalization coefficients remain hidden (only downstream effects surfaced).
- Autonomy: enabled immediately for all tenants; GLOBAL_AUTONOMY_PAUSE triggers only by hard invariant violations (not early warnings).
