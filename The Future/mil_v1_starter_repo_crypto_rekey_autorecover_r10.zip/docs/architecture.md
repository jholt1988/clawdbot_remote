# Architecture (r2)

This repo provides a runnable baseline for:
- MIL edge overlay workflow (candidate → approve-first → activate)
- PM-RE Monte Carlo simulation (minimal but working)
- Workflow Engine ActionIntents (autonomous execute stub)

Locked decisions are captured in `docs/decisions.md`.
